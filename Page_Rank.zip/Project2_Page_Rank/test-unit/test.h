//
// Created by explo on 4/8/2023.
//

#ifndef PROJECT2_PAGE_RANK_TEST_H
#define PROJECT2_PAGE_RANK_TEST_H


class test {

};


#endif //PROJECT2_PAGE_RANK_TEST_H
