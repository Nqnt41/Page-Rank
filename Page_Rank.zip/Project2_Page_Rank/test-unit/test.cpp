/*TEST_CASE("1000+ Insertions into from position", "[flag]") {
    AdjacencyList CreatedGraph;
    for (int i = 0; i < 1000; i++) {
        CreatedGraph.insertNode(to_string(i), "MainNode");
    }
    //Create the graph object and output result.
    map<string, float> resultMatrix = CreatedGraph.pageRankTesting(2);

    // Check that all nodes named 0 to 999 are equal to 0, as they should be.
    bool numericalEdgesFunction = true;
    for (int i = 0; i < 1000; i++) {
        if (resultMatrix[to_string(i)] != 0.00) {
            numericalEdgesFunction = false;
        }
    }
    // Check that size is correct.
    REQUIRE(resultMatrix.size() == 1001);
    // Check that MainNode has the correct rank, accounting for rounding.
    REQUIRE(resultMatrix["MainNode"] >= 0.99);
    // Get the bool value of numericalEdgesFunction.
    REQUIRE(numericalEdgesFunction);
}

TEST_CASE("1000+ Insertions into from position", "[flag]") {
    AdjacencyList CreatedGraph;
    for (int i = 0; i < 1000; i++) {
        CreatedGraph.insertNode("MainNode", to_string(i));
    }
    //Create the graph object and output result.
    map<string, float> resultMatrix = CreatedGraph.pageRankTesting(2);

    // Check that all nodes named 0 to 999 are equal to 0, as they should be. Account for the fact that resultMatrix[to_string(i)] is not yet rounded to the hundredths as well.
    bool numericalEdgesFunction = true;
    for (int i = 0; i < 1000; i++) {
        if (resultMatrix[to_string(i)] >= 0.01) {
            numericalEdgesFunction = false;
        }
    }
    // Check that size is correct.
    REQUIRE(resultMatrix.size() == 1001);
    // Check that MainNode has the correct rank, accounting for rounding.
    REQUIRE(resultMatrix["MainNode"] <= 0.00);
    // Get the bool value of numericalEdgesFunction.
    REQUIRE(numericalEdgesFunction);
}

TEST_CASE("Test numIterations = 1", "[flag]") {
    AdjacencyList CreatedGraph;
    for (int i = 0; i < 100; i++) {
        CreatedGraph.insertNode("MainNode", to_string(i));
    }
    //Create the graph object and output result.
    map<string, float> resultMatrix = CreatedGraph.pageRankTesting(1);

    // Check that all nodes named 1 to 99 have a rank of 0.01, accounting for their not being rounded yet.
    bool numericalEdgesFunction = true;
    for (int i = 0; i < 100; i++) {
        if (resultMatrix[to_string(i)] < 0.009 && resultMatrix[to_string(i)] > 0.011) {
            numericalEdgesFunction = false;
        }
    }
    // Check that size is correct.
    REQUIRE(resultMatrix.size() == 101);
    // Check that value of MainNode is 0.01. Account for it not being rounded as well.
    REQUIRE(resultMatrix["MainNode"] > 0.009 && resultMatrix["MainNode"] < 0.011);
    // Get the bool value of numericalEdgesFunction.
    REQUIRE(numericalEdgesFunction);
}

TEST_CASE("Test numIterations = 1000", "[flag]") {
    AdjacencyList CreatedGraph;
    // Insert four nodes.
    CreatedGraph.insertNode("FirstNode", "FourthNode");
    CreatedGraph.insertNode("SecondNode", "FourthNode");
    CreatedGraph.insertNode("ThirdNode", "FourthNode");
    //Create the graph object and output result. Make sure program can handle a large value for numIterations.
    map<string, float> resultMatrix = CreatedGraph.pageRankTesting(1000);

    // Check that the size of the matrix is four.
    REQUIRE (resultMatrix.size() == 4);
    // Check that all four named nodes have a value of zero.
    REQUIRE (resultMatrix["FirstNode"] == 0);
    REQUIRE (resultMatrix["SecondNode"] == 0);
    REQUIRE (resultMatrix["ThirdNode"] == 0);
    REQUIRE (resultMatrix["FourthNode"] == 0);
}

TEST_CASE("Test multiple to nodes", "[flag]") {
    AdjacencyList CreatedGraph;
    for (int i = 0; i < 10; i++) {
        CreatedGraph.insertNode(to_string(i), "FirstNode");
    }
    for (int i = 10; i < 30; i++) {
        CreatedGraph.insertNode(to_string(i), "SecondNode");
    }
    for (int i = 30; i < 60; i++) {
        CreatedGraph.insertNode(to_string(i), "ThirdNode");
    }
    //Create the graph object and output result.
    map<string, float> resultMatrix = CreatedGraph.pageRankTesting(2);

    // Check that all nodes named 0 to 59 are equal to 0, as they should be.
    bool numericalEdgesFunction = true;
    for (int i = 0; i < 60; i++) {
        if (resultMatrix[to_string(i)] != 0.00) {
            numericalEdgesFunction = false;
        }
    }
    // Check that size is correct.
    REQUIRE(resultMatrix.size() == 63);
    // Individually check that all three named nodes have the correct rank, accounting for the fact that none of them are rounded.
    REQUIRE (resultMatrix["FirstNode"] < 0.16 && resultMatrix["FirstNode"] > 0.154);
    REQUIRE (resultMatrix["SecondNode"] < 0.32 && resultMatrix["SecondNode"]);
    REQUIRE (resultMatrix["ThirdNode"] < 0.48 && resultMatrix["ThirdNode"] > 0.474);
    // Get the bool value of numericalEdgesFunction.
    REQUIRE(numericalEdgesFunction);
}*/