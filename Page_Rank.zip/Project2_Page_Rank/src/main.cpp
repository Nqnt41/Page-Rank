#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
using namespace std;

// Project 2: PageRank implementation by Ryan Coveny

class AdjacencyList {
// Private adjacency list data structure:
private:
    // Adjacency list containing a string for toPage and a map with keys of strings representing fromPage and values representing rank as a float
    map<string, vector<pair<string, float>>> graph;
// Public helper functions:
public:
    void insertNode(string fromPage, string toPage);
    void updateRanks();
    float findOutdegree(string fromPage);
    vector<string> getUrlList();
    map<string, float> powerIteration(int numIterations);
    void pageRank(int numIterations);
    map<string, float> pageRankTesting(int numIterations);
};

// Add a new node to the adjacency list. Uses structure graph[toPage][fromPage].
void AdjacencyList::insertNode(string fromPage, string toPage) {
    if (graph.find(toPage) == graph.end()) {
        graph[toPage] = {};
    }
    // Add node and set default rank to one.
    graph[toPage].push_back(make_pair(fromPage, 1.00));
    // Use the updateRanks command to set the rank for the newly added node as well as every node already in the list.
    updateRanks();
}

// Use nested iterator loops to set the rank for every node present in the list.
void AdjacencyList::updateRanks() {
    for (auto iter = graph.begin(); iter != graph.end(); iter++) {
        for (auto iter2 = iter->second.begin(); iter2 != iter->second.end(); iter2++) {
            // Value of node currently being considered is equal to 1/outdegree. Call findOutdegree for current node.
            iter2->second = 1/findOutdegree(iter2->first);
        }
    }
}

// Count how many nodes point to the main node.
float AdjacencyList::findOutdegree(string mainNode) {
    float outdegree = 0.00;
    // Nested for loops used to iterate through the entire graph structure.
    for (auto iter = graph.begin(); iter != graph.end(); iter++) {
        for (auto iter2 = iter->second.begin(); iter2 != iter->second.end(); iter2++) {
            // If the currently considered node is a match to the main node inputted to the function, increase outdegree.
            if (iter2->first == mainNode) {
                outdegree++;
            }
        }
    }
    // If there are nodes that point to the main node, return that number of nodes.
    if (outdegree != 0) {
        return outdegree;
    }
    // If there are no nodes pointing to the main node, return 1 instead of 0 to prevent dividing by zero.
    else {
        return 1;
    }
}

// Attain a vector acting as a list of every url inputted into the function.
// Used for both testing (to make sure every necessary node accounted for) and within the powerIteration function.
vector<string> AdjacencyList::getUrlList() {
    vector<string> urlList;
    // Use a nested for loop to iterate through every node inputted into the graph structure to find every url within.
    // If the node is not already part of the urlList vector, add it.
    for (auto iter = graph.begin(); iter != graph.end(); iter++) {
        if (find(urlList.begin(), urlList.end(), iter->first) == urlList.end()) {
            urlList.push_back(iter->first);
        }
        for (auto iter2 = iter->second.begin(); iter2 != iter->second.end(); iter2++) {
            if (find(urlList.begin(), urlList.end(), iter2->first) == urlList.end()) {
                urlList.push_back(iter2->first);
            }
        }
    }
    // Sort the list of urls alphabetically.
    sort(urlList.begin(), urlList.end());
    return urlList;
}

// Function used to multiply the main graph list by the nx1 matrix representing the ranks of each webpage.
map<string, float> AdjacencyList::powerIteration(int numIterations) {
    string ref = graph.begin()->first;
    map<string, float> previousIteration, resultMatrix;
    // Grab all the URLs used in the program - used in the loop below and to set graphSize.
    vector<string> urlList = getUrlList();
    int graphSize = urlList.size();

    //for (auto iter = graph.begin(); iter != graph.end(); iter++) {
    for (int i = 0; i < graphSize; i++) {
        if (resultMatrix.find(urlList[i]) == resultMatrix.end()) {
            previousIteration[urlList[i]] = 1.0 / graphSize;
            resultMatrix[urlList[i]] = 1.0 / graphSize;
        }
    }
    // If multiplication is needed, enter this if statement. Otherwise, return resultMatrix as it is.
    if (numIterations > 1) {
        // Use a for loop to perform multiplication as many times as specified by numIterations.
        for (int i = 1; i < numIterations; i++) {
            // Turn every value in resultMatrix to 0 in order to prepare for the incoming loop.
            for (auto iter3 = resultMatrix.begin(); iter3 != resultMatrix.end(); iter3++) {
                iter3->second = 0.00;
            }
            // Use a nested for loop to multiply the nx1 matrix by the main graph to perform matrix multiplication.
            for (auto iter = graph.begin(); iter != graph.end(); iter++) {
                for (auto iter2 = iter->second.begin(); iter2 != iter->second.end(); iter2++) {
                    resultMatrix[iter->first] += previousIteration[iter2->first]*iter2->second;
                }
            }
            // Save the new values of resultMatrix to the previousIteration matrix.
            previousIteration = resultMatrix;
        }
    }
    return resultMatrix;
}

// pageRank function used to output result of the system.
void AdjacencyList::pageRank(int numIterations){
    // Call powerIteration to perform the necessary operations with the graph system.
    map<string, float> resultMatrix = powerIteration(numIterations);
    // Output the  final data via an iterator loop.
    for (auto iter = resultMatrix.begin(); iter != resultMatrix.end(); iter++) {
        cout << iter->first << " " << fixed << showpoint << setprecision(2) << iter->second << endl;
    }
}

// Alternate pageRank function that returns the graph function so that it can be used for the test cases.
map<string, float> AdjacencyList::pageRankTesting(int numIterations) {
    // Call powerIteration to perform the necessary operations with the graph system.
    map<string, float> resultMatrix = powerIteration(numIterations);
    // Output the  final data via an iterator loop.
    for (auto iter = resultMatrix.begin(); iter != resultMatrix.end(); iter++) {
        cout << iter->first << " " << fixed << showpoint << setprecision(2) << iter->second << endl;
    }
    return resultMatrix;
}

// Set up variables and get necessary input within main.
int main() {
    AdjacencyList CreatedGraph;
    int numLines, powerIterations;
    string fromPage, toPage;
    cin >> numLines;
    cin >> powerIterations;
    for(int i = 0; i < numLines; i++) {
        cin >> fromPage;
        cin >> toPage;
        // Call insertNode to add the input to the adjacency list.
        CreatedGraph.insertNode(fromPage, toPage);
    }
    //Create the graph object and output result.
    CreatedGraph.pageRank(powerIterations);
    return 0;
}